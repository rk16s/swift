print ("Hi everyone in GPA cal ")
 print ( "please enter your marks ")
if let marks = readLine() {
    print ( marks )
}
//var marks
if ( marks >= 95  && marks < 100) {
    print ("your grade is A+")
}
else if ( marks >= 90 && marks < 95 ){
    print ( "your grade is A")
}
else if ( marks >= 85 && marks < 90 ) {
    print ("your grade is B+")
}
else if (marks >= 80 && marks < 85) {
    print ("your grade is B")
}
else if (marks >= 75 && marks < 80) {
    print ("your grade is C+")
}
else if (marks >= 70 && marks < 75 ){
    print ("your grade is C ")
}
else if (marks >= 65 && marks < 70 ){
    print ("your grade is D+ ")
}
else if (marks >= 60 && marks < 65 ){
    print ("your grade is D ")
}
else if (marks >= 0 && marks < 60 ) {
    print ("your grade is F ")
}
else {
    print ("Your Enter wrong value ")
}
